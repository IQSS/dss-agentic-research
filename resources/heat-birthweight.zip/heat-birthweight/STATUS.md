# Project status

Last updated: 2026-11-10

## Current state

The synthetic 1,200-record analysis, 400 repetitions per simulation scenario, and independent R/Python comparison have saved outputs. The paper layout and current scientific records now accompany the worked example. The reorganized scripts passed analysis, smoke-test, figure, and independent-result comparisons in a scratch copy; see `docs/notes/layout-validation.md`.

## Established results

The two primary implementations agree within the specified tolerance. The curved simulation scenario exposes poor age-28 performance under the unchanged estimator; retain that result. No failed fits occurred in the saved full simulation.

## Limitations

Clean-machine restoration of the R environment remains untested. The analysis uses synthetic data and does not establish performance for observed births.

## Next action

Follow `README.md` to inspect or reproduce the example. Use `TASKS.md` for outstanding checks and `SPECIFICATION.md` for scientific requirements.
