# Project status

**Stage:** Reproducible synthetic example with saved analysis and simulation results.

Last updated: 2026-11-10

## Headline

The R and Python implementations agree within the specified tolerance on 1,200 synthetic records. The curved scenario shows poor age-28 performance under the unchanged estimator. No full-simulation fits failed.

## Now

The worked example is available for inspection through the README.

## Blocked / waiting on

None recorded.

## Standing facts

The saved full simulation uses 400 repetitions per scenario. `SPECIFICATION.md` gives the analysis and comparison requirements.

## Watch items

Clean-machine R restoration remains untested. The synthetic example does not establish performance on observed births.
