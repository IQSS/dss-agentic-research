# Synthetic heat exposure and birthweight: analysis specification

Current approved requirements for the fully synthetic teaching study. Updated November 10, 2026 for the paper-project layout; the scientific requirements are unchanged.

Question: How does a mother’s exposure to heat during pregnancy relate to her baby’s birthweight, and does that relationship vary with maternal age?

## Data and analysis sample

Use `data/raw/births.csv`, with one independent record per `id`. Variables are `age` (18–40 years inclusive), `hot_days` (0–20 days), `smoker` (0 or 1), and `birthweight_g` (positive grams). All 1,200 records belong in the primary analysis. Verify unique ids, valid ranges, and complete inputs. Fail if the supplied file violates these requirements; do not drop rows or invent replacements.

Define `age_c = age - 28`. Fit ordinary least squares with an intercept and the following terms, in this order: `hot_days`, `age_c`, `age_c^2`, `smoker`, and `hot_days * age_c`. The model is equivalent to `birthweight_g ~ hot_days * age_c + I(age_c^2) + smoker` in R. Use the HC3 covariance estimator, with the squared residual divided by the square of one minus the leverage for each observation. Preserve the fitted model and its coefficient/covariance estimates.

## Quantities to report

The primary estimand is the mean difference in predicted birthweight at 10 versus 5 hot days, averaging over the sample's observed age and smoking distribution. Report it as a sample-standardized contrast, in grams, with direction 10 minus 5.

Also report that contrast at ages 22, 28, and 36. For each age, replace age in every row with that age and preserve each row's smoking value. Recalculate `age_c` and its squared term from the replaced age. Compare predictions at 10 and 5 hot days and average across those rows. These are age-specific standardized contrasts; they are not model coefficients.

Use delta-method standard errors from the HC3 covariance matrix and two-sided 95% confidence intervals with the standard normal critical value. Report full-precision results before formatting for a manuscript. All contrasts concern this synthetic sample; do not label them population causal effects.

Save analysis tables in `outputs/results/analysis/`. Write `contrasts.csv` with columns `quantity`, `estimate`, `std_error`, `conf_low`, `conf_high`, using quantities `sample`, `age_22`, `age_28`, and `age_36`. Also write sample ids, the coefficient table, the covariance matrix with named rows/columns, fitted values by id, and a software-version record. Expose a saved command to reproduce those outputs.

## Independent implementation

The original input is preserved unchanged in [the frozen specification](docs/notes/independent-implementation-specification.md). The completed R/Python comparison used that version. Keep it with the original results; do not substitute this updated record in the historical check.


Implement from this specification and the original CSV. Do not read another implementation, its intermediate files, or its results. Record any ambiguity and resolve it explicitly before comparing outputs. Once each implementation is complete, compare sample ids and design terms before fitted values and contrasts. Use an absolute tolerance of 1e-6 grams for estimates and interval bounds and 1e-6 for standard errors. Investigate discrepancies rather than changing the specification or tolerance to obtain agreement.

## Simulation requirements

Follow the [simulation specification](docs/notes/simulation-specification.md). Keep the primary estimator unchanged across the declared scenarios and retain failures in the accounting.

## Saved outputs and records

- `data/processed/analysis-data.rds`: checked analysis input.
- `outputs/models/`: fitted model and covariance.
- `outputs/results/analysis/`: full-precision estimates, sample, design, fitted values, and software versions.
- `outputs/results/simulation/`: all 400 repetitions per scenario, checks, failures, and summaries.
- `outputs/results/validation/` and `outputs/results/verification/`: within-implementation checks and independent comparison.
- `outputs/figures/final/`: figures made from saved results; generator diagnostics go in `working/`.
- `manuscript/results.md`: illustrative reporting from the saved contrast table.

After an approved scientific change, rewrite the affected requirements here and add a dated explanation at the top of [METHODOLOGY.md](METHODOLOGY.md). Preserve the specification and results for completed runs.
