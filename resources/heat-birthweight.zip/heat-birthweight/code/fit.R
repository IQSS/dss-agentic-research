source(here::here("code", "_startup", "init.R"))

dat <- read_births()
fit <- fit_model(dat)
covariance <- hc3_covariance(fit)
dir.create(here::here("outputs", "models"), recursive = TRUE, showWarnings = FALSE)
dir.create(here::here("data", "processed"), recursive = TRUE, showWarnings = FALSE)
saveRDS(fit, here::here("outputs", "models", "fit.rds"))
saveRDS(dat, here::here("data", "processed", "analysis-data.rds"))
saveRDS(covariance, here::here("outputs", "models", "covariance.rds"))
write_table(dplyr::select(dat, id), "analysis", "sample-ids.csv")
write_table(data.frame(term = names(coef(fit)), estimate = coef(fit),
                       std_error = sqrt(diag(covariance))), "analysis", "coefficients.csv")
write_table(data.frame(term = rownames(covariance), covariance, check.names = FALSE),
            "analysis", "covariance.csv")
write_table(data.frame(id = dat$id, fitted = fitted(fit)), "analysis", "fitted-values.csv")
write_table(data.frame(id = dat$id, model.matrix(fit), check.names = FALSE),
            "analysis", "design-matrix.csv")
write_table(software_versions(), "analysis", "software-versions.csv")
cat("Saved the full 1,200-record fit and HC3 covariance.\n")
