source(here::here("setup.R"))
source(here::here("code", "simulation-functions.R"))

dat <- read_births()
input_cases <- data.frame(
  check = c("age_lower_boundary", "age_upper_boundary", "age_below_range", "age_above_range",
             "exposure_lower_boundary", "exposure_upper_boundary", "fractional_exposure",
             "exposure_below_range", "exposure_above_range"),
  field = c(rep("age", 4), rep("hot_days", 5)),
  value = c(18, 40, 17.99, 40.01, 0, 20, 7.5, -0.01, 20.01),
  should_pass = c(TRUE, TRUE, FALSE, FALSE, TRUE, TRUE, TRUE, FALSE, FALSE)
)
input_cases$accepted <- purrr::map_lgl(seq_len(nrow(input_cases)), function(i) {
  candidate <- dat
  candidate[[input_cases$field[i]]][1] <- input_cases$value[i]
  tryCatch({validate_births(candidate); TRUE}, error = function(e) FALSE)
})
input_cases$passed <- input_cases$accepted == input_cases$should_pass
stopifnot(all(input_cases$passed))
write_table(input_cases, "validation", "input-boundaries.csv")
oracle_checks(dat, "validation")
dat$birthweight_g <- generate_outcome(dat, "main", 20261103L)
fit <- fit_model(dat)
covariance <- hc3_covariance(fit)
x <- stats::model.matrix(fit)
expected_terms <- c("(Intercept)", "hot_days", "age_c", "I(age_c^2)",
                    "smoker", "hot_days:age_c")
stopifnot(identical(colnames(x), expected_terms))

# Independent algebraic checks validate library output; production uses the libraries.
bread <- solve(crossprod(x))
meat <- crossprod(x, x * (stats::residuals(fit) / (1 - stats::hatvalues(fit)))^2)
covariance_check <- bread %*% meat %*% bread
stopifnot(max(abs(covariance - covariance_check)) < 1e-8)
contrasts <- estimate_contrasts(fit, dat, covariance)
gradient <- matrix(0, nrow = 4, ncol = ncol(x), dimnames = list(contrasts$quantity, colnames(x)))
gradient[, "hot_days"] <- 5
gradient[, "hot_days:age_c"] <- 5 * c(mean(dat$age_c), 22 - 28, 28 - 28, 36 - 28)
expected <- drop(gradient %*% stats::coef(fit))
expected_se <- sqrt(diag(gradient %*% covariance %*% t(gradient)))
stopifnot(max(abs(contrasts$estimate - expected)) < 1e-6,
          max(abs(contrasts$std_error - expected_se)) < 1e-6)
stopifnot(wilson_interval(0L, 400L)[[2]] > 0,
          wilson_interval(400L, 400L)[[1]] < 1)
write_table(data.frame(quantity = contrasts$quantity,
                       estimate_difference = contrasts$estimate - expected,
                       standard_error_difference = contrasts$std_error - expected_se),
            "validation", "contrast-algebra.csv")
write_table(data.frame(check = c("unique_complete_1200_rows", "specified_design_terms",
                                 "hc3_formula", "contrast_estimates", "contrast_standard_errors",
                                 "nonzero_mc_uncertainty_at_boundaries", "input_range_boundaries",
                                 "fractional_exposure_allowed"),
                       passed = TRUE), "validation", "checks.csv")
cat("Data, design, oracle, HC3, and contrast checks passed.\n")
