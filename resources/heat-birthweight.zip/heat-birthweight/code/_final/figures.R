source(here::here("code", "_startup", "init.R"))
source(here::here("code", "_startup", "simulation.R"))

save_figure <- function(plot, stem, width, height) {
  group <- if (stem == "generator-check") "working" else "final"
  dir.create(here::here("outputs", "figures", group), recursive = TRUE, showWarnings = FALSE)
  for (extension in c("png", "pdf")) {
    ggplot2::ggsave(here::here("outputs", "figures", group, paste0(stem, ".", extension)),
                    plot = plot, width = width, height = height, dpi = 180, bg = "white")
  }
}

readr::read_csv(here::here("outputs", "results", "analysis", "contrasts.csv"), show_col_types = FALSE) |>
  dplyr::mutate(quantity = factor(quantity, levels = c("age_36", "age_28", "age_22", "sample"),
                                 labels = c("Age 36", "Age 28", "Age 22", "Observed sample"))) ->
contrasts
ggplot(contrasts, aes(estimate, quantity)) +
  geom_vline(xintercept = 0, color = "grey60", linetype = "dashed") +
  geom_errorbar(aes(xmin = conf_low, xmax = conf_high), width = 0.16, orientation = "y") +
  geom_point(size = 3, color = "#176B83") +
  labs(title = "Contrasts from synthetic birth records", x = "10 minus 5 hot days (grams)", y = NULL,
       subtitle = "Sample-standardized predictions; HC3 normal 95% confidence intervals",
       caption = "Wholly synthetic teaching example. These are not estimates about real pregnancies.") +
  theme_minimal(base_size = 12) ->
contrast_plot
save_figure(contrast_plot, "contrasts", 9, 4.5)

readr::read_csv(here::here("outputs", "results", "simulation", "summary.csv"), show_col_types = FALSE) |>
  dplyr::mutate(quantity = factor(quantity, levels = c("sample", "age_22", "age_28", "age_36"),
                                 labels = c("Sample", "Age 22", "Age 28", "Age 36")),
                 scenario = factor(scenario, levels = c("null", "main", "curved"),
                                   labels = c("Null", "Main", "Curved modifier"))) ->
summary
ggplot(summary, aes(quantity, bias)) +
  geom_hline(yintercept = 0, color = "grey60", linetype = "dashed") +
  geom_errorbar(aes(ymin = bias - qnorm(0.975) * bias_mc_se,
                    ymax = bias + qnorm(0.975) * bias_mc_se), width = 0.16) +
  geom_point(size = 2.8, color = "#176B83") +
  facet_wrap(~ scenario, nrow = 1) +
  labs(title = "Can the fixed procedure recover known contrasts?", x = NULL, y = "Bias (grams)",
       subtitle = "400 simulated outcomes per scenario on the same covariate design",
       caption = "Error bars: approximate 95% Monte Carlo intervals for mean estimation error.\nThe curved scenario exceeds the fitted interaction form; the estimator stays fixed.") +
  theme_minimal(base_size = 12) ->
bias_plot
save_figure(bias_plot, "simulation-bias", 11, 4.5)

dplyr::bind_rows(
  dplyr::transmute(summary, scenario, quantity, metric = "95% interval coverage",
                   rate = coverage, lower = coverage_mc_low, upper = coverage_mc_high),
  dplyr::transmute(summary, scenario, quantity, metric = "Interval excludes zero",
                   rate = excludes_zero, lower = excludes_zero_mc_low, upper = excludes_zero_mc_high)
) ->
rates
data.frame(metric = c("95% interval coverage", "Interval excludes zero"),
           reference = c(0.95, 0.05)) ->
reference
ggplot(rates, aes(quantity, rate)) +
  geom_hline(data = reference, aes(yintercept = reference), color = "grey60", linetype = "dashed") +
  geom_errorbar(aes(ymin = lower, ymax = upper), width = 0.16) +
  geom_point(size = 2.6, color = "#176B83") +
  facet_grid(metric ~ scenario) +
  scale_y_continuous(limits = c(0, 1), breaks = c(0, 0.25, 0.5, 0.75, 1)) +
  labs(title = "Interval behavior across known worlds", x = NULL, y = "Proportion of successful runs",
       caption = "Bars: 95% Wilson binomial Monte Carlo intervals. Excluding zero is a false positive only in the null world.\nDashed references: 0.95 coverage and 0.05 exclusion; exclusion under alternatives measures sensitivity.") +
  theme_minimal(base_size = 11) ->
rate_plot
save_figure(rate_plot, "simulation-interval-rates", 11, 7)

dat <- read_births()
purrr::map_dfr(c("null", "main", "curved"), function(scenario) {
  readr::read_csv(here::here("outputs", "results", "simulation", paste0("generator-example-", scenario, ".csv")),
                  show_col_types = FALSE) |>
    dplyr::transmute(outcome, dataset = scenario)
}) |>
  dplyr::bind_rows(data.frame(outcome = dat$birthweight_g, dataset = "Supplied invented records")) ->
generator_data
ggplot(generator_data, aes(outcome, color = dataset)) +
  geom_density(linewidth = 0.8) +
  scale_y_continuous(labels = function(x) formatC(x, format = "f", digits = 5)) +
  labs(title = "Outcome support and spread before repeated fitting", x = "Invented birthweight (grams)",
       y = "Density", color = NULL,
       subtitle = "One generated dataset per scenario compared with the supplied synthetic records",
       caption = "Positive multiplicative outcomes; intended conditional mean and variance are checked separately.") +
  theme_minimal(base_size = 12) +
  theme(legend.position = "bottom") ->
generator_plot
save_figure(generator_plot, "generator-check", 10, 5)
cat("Saved four figures as PNG and PDF.\n")
