# Create synthetic individual records and preserve the generator's provenance.
args <- commandArgs(trailingOnly = FALSE)
script_file <- sub("^--file=", "", args[grepl("^--file=", args)])
root <- normalizePath(file.path(dirname(script_file), "..", ".."))
stopifnot(file.exists(file.path(root, ".here")))

set.seed(20261103)
n <- 1200L
age <- sample(18:40, n, replace = TRUE)
age_c <- age - 28
smoker <- rbinom(n, 1, plogis(-1.5 - 0.03 * age_c))
hot_days <- rbinom(n, 20, plogis(-0.6 + 0.03 * age_c + 0.3 * smoker))
mu <- 3500 - 1.4 * age_c^2 - 140 * smoker + hot_days * (-8 + 0.5 * age_c)
birthweight_g <- mu * exp(0.10 * rnorm(n) - 0.10^2 / 2)
births <- data.frame(id = seq_len(n), age, hot_days, smoker, birthweight_g)
stopifnot(all(mu > 0), all(births$birthweight_g > 0), !anyDuplicated(births$id))

raw_dir <- file.path(root, "data", "raw")
dir.create(raw_dir, recursive = TRUE, showWarnings = FALSE)
destination <- file.path(raw_dir, "births.csv")
if (file.exists(destination)) {
  existing <- read.csv(destination)
  if (!isTRUE(all.equal(existing, births, tolerance = 1e-12))) {
    stop("Existing original differs from this generation; preserve it and choose a new destination.")
  }
} else {
  write.csv(births, destination, row.names = FALSE)
}
writeLines(c(
  "# Input provenance",
  "",
  "Source: entirely synthetic individual-level teaching data; no observed birth records.",
  "Generator: code/_data-acquisition/generate-data.R; seed 20261103; 1,200 independent rows.",
  paste("R version:", R.version.string),
  "Variables: data/raw/data-dictionary.md. Analysis requirements: SPECIFICATION.md.",
  paste("Original file MD5:", unname(tools::md5sum(destination))),
  "The checksum detects changed bytes; it does not establish scientific validity."
), file.path(raw_dir, "sources.md"))
cat("Created or verified", nrow(births), "synthetic records.\n")
