source(here::here("setup.R"))

fit <- readRDS(here::here("outputs", "analysis", "fit.rds"))
dat <- readRDS(here::here("outputs", "analysis", "analysis-data.rds"))
covariance <- readRDS(here::here("outputs", "analysis", "covariance.rds"))
contrasts <- estimate_contrasts(fit, dat, covariance)
write_table(contrasts, "analysis", "contrasts.csv")
print(contrasts, row.names = FALSE)
