source(here::here("code", "_startup", "init.R"))

fit <- readRDS(here::here("outputs", "models", "fit.rds"))
dat <- readRDS(here::here("data", "processed", "analysis-data.rds"))
covariance <- readRDS(here::here("outputs", "models", "covariance.rds"))
contrasts <- estimate_contrasts(fit, dat, covariance)
write_table(contrasts, "analysis", "contrasts.csv")
print(contrasts, row.names = FALSE)
