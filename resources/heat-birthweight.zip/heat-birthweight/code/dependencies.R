# Static dependency declarations; this file is not sourced.
library(here)
library(dplyr)
library(purrr)
library(readr)
library(ggplot2)
library(marginaleffects)
library(sandwich)
library(renv)
