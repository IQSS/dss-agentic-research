source(here::here("setup.R"))
source(here::here("code", "simulation-functions.R"))

args <- commandArgs(trailingOnly = TRUE)
repetitions <- if (length(args)) as.integer(args[1]) else 400L
stopifnot(length(repetitions) == 1L, is.finite(repetitions), repetitions > 1L)
output_group <- if (repetitions == 400L) "simulation" else "simulation-smoke"
dat <- read_births()
write_table(dplyr::select(dat, id, age, hot_days, smoker, age_c),
            output_group, "fixed-design.csv")
generator_checks(dat, output_group)
oracle_checks(dat, output_group)

scenarios <- c("null", "main", "curved")
results <- list()
accounting <- list()
warnings_record <- list()
started <- proc.time()[["elapsed"]]
for (scenario_index in seq_along(scenarios)) {
  scenario <- scenarios[scenario_index]
  truth <- truth_contrasts(dat, scenario)
  for (replicate in seq_len(repetitions)) {
    seed <- 20270000L + 10000L * scenario_index + replicate
    key <- paste(scenario, replicate, sep = "-")
    warnings_seen <- character()
    result <- tryCatch(withCallingHandlers({
      simulated <- dplyr::mutate(dat, birthweight_g = generate_outcome(dat, scenario, seed))
      stopifnot(all(is.finite(simulated$birthweight_g)), all(simulated$birthweight_g > 0))
      fit <- fit_model(simulated)
      estimate_contrasts(fit, simulated) |>
        dplyr::left_join(truth, by = "quantity") |>
        dplyr::mutate(scenario, replicate, seed, .before = 1)
    }, warning = function(w) {
      warnings_seen <<- c(warnings_seen, conditionMessage(w))
      invokeRestart("muffleWarning")
    }), error = function(e) e)
    failed <- inherits(result, "error")
    accounting[[key]] <- data.frame(scenario, replicate, seed,
                                    status = if (failed) "failed" else "success",
                                    error = if (failed) conditionMessage(result) else "")
    if (!failed) results[[key]] <- result
    if (length(warnings_seen)) {
      warnings_record[[key]] <- data.frame(scenario, replicate, seed,
                                            warning = warnings_seen)
    }
    if (replicate %% 25L == 0L || replicate == repetitions) {
      cat(scenario, replicate, "of", repetitions, "completed; elapsed seconds:",
          round(proc.time()[["elapsed"]] - started, 1), "\n")
    }
  }
  # Persist each completed scenario so partial execution remains reviewable.
  write_table(dplyr::bind_rows(results), output_group, "replicates.csv")
  write_table(dplyr::bind_rows(accounting), output_group, "run-accounting.csv")
}
results <- dplyr::bind_rows(results)
accounting <- dplyr::bind_rows(accounting)
summary <- summarize_simulations(results, repetitions)
write_table(summary, output_group, "summary.csv")
write_table(dplyr::filter(accounting, status == "failed"), output_group, "failed-runs.csv")
warnings_record <- dplyr::bind_rows(
  data.frame(scenario = character(), replicate = integer(), seed = integer(),
             warning = character()), warnings_record)
write_table(warnings_record, output_group, "warnings.csv")
write_table(software_versions(), output_group, "software-versions.csv")
stopifnot(nrow(accounting) == 3L * repetitions)
writeLines(c(paste("attempted", nrow(accounting)),
             paste("succeeded", sum(accounting$status == "success")),
             paste("failed", sum(accounting$status == "failed"))),
           here::here("outputs", output_group, "complete.txt"))
cat("Saved simulation results and explicit accounting.\n")
