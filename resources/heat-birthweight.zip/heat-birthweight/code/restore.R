# Bootstrap cannot use here until the locked dependencies have been restored.
script_argument <- commandArgs(trailingOnly = FALSE)
script_argument <- script_argument[startsWith(script_argument, "--file=")]
stopifnot(length(script_argument) == 1L)
script_path <- normalizePath(sub("^--file=", "", script_argument), mustWork = TRUE)
project_root <- dirname(dirname(script_path))
stopifnot(file.exists(file.path(project_root, "renv.lock")),
          file.exists(file.path(project_root, ".here")))
if (!requireNamespace("renv", quietly = TRUE)) {
  stop("Install renv before running just restore; see environment-setup.txt.")
}
project_library <- renv::paths$library(project = project_root)
renv::restore(project = project_root, library = project_library, prompt = FALSE)
renv::activate(project = project_root)
renv::status(project = project_root, library = project_library)
cat("Restored the project library and wrote its renv activation files.\n")
