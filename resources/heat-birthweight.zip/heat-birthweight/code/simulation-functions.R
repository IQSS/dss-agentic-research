generating_mean <- function(dat, scenario) {
  age_c <- dat$age - 28
  slope <- switch(scenario, null = rep(0, nrow(dat)),
                  main = -8 + 0.5 * age_c,
                  curved = -8 + 0.5 * age_c + 0.12 * age_c^2,
                  stop("Unknown scenario."))
  3500 - 1.4 * age_c^2 - 140 * dat$smoker + dat$hot_days * slope
}

truth_contrasts <- function(dat, scenario) {
  # Truth is a contrast of declared means, independent of any fitted model.
  rows <- standardization_rows(dat)
  lower <- dplyr::mutate(rows, hot_days = 5)
  upper <- dplyr::mutate(rows, hot_days = 10)
  rows$truth <- generating_mean(upper, scenario) - generating_mean(lower, scenario)
  rows |>
    dplyr::group_by(quantity) |>
    dplyr::summarise(truth = mean(truth), .groups = "drop")
}

generate_outcome <- function(dat, scenario, seed) {
  set.seed(seed)
  mu <- generating_mean(dat, scenario)
  stopifnot(all(is.finite(mu)), all(mu > 0))
  mu * exp(0.10 * stats::rnorm(nrow(dat)) - 0.10^2 / 2)
}

generator_checks <- function(dat, output_group) {
  # Analytic lognormal multiplier moments are checked independently by simulation.
  set.seed(20261130L)
  moment_n <- 1000000L
  multipliers <- exp(0.10 * stats::rnorm(moment_n) - 0.10^2 / 2)
  variance <- exp(0.10^2) - 1
  fourth_central <- exp(6 * 0.10^2) - 4 * exp(3 * 0.10^2) +
    6 * exp(0.10^2) - 3
  mean_mc_se <- sqrt(variance / moment_n)
  variance_mc_se <- sqrt((fourth_central - variance^2) / moment_n)
  stopifnot(all(multipliers > 0),
            abs(mean(multipliers) - 1) < 6 * mean_mc_se,
            abs(stats::var(multipliers) - variance) < 6 * variance_mc_se)
  write_table(data.frame(
    seed = 20261130L, n = moment_n, expected_mean = 1,
    observed_mean = mean(multipliers), mean_mc_se,
    expected_variance = variance, observed_variance = stats::var(multipliers),
    variance_mc_se, support_pass = all(multipliers > 0)
  ), output_group, "generator-moments.csv")

  purrr::map_dfr(seq_along(c("null", "main", "curved")), function(i) {
    scenario <- c("null", "main", "curved")[i]
    mu <- generating_mean(dat, scenario)
    seed <- 20262000L + i
    y <- generate_outcome(dat, scenario, seed)
    sd_ratio <- stats::sd(y) / stats::sd(dat$birthweight_g)
    outside <- mean(y < min(dat$birthweight_g) | y > max(dat$birthweight_g))
    stopifnot(all(y > 0), all(is.finite(y)),
              all(dat$age >= 18 & dat$age <= 40),
              all(dat$hot_days >= 0 & dat$hot_days <= 20),
              all(dat$smoker %in% c(0, 1)))
    if (sd_ratio < 0.5 || sd_ratio > 2 || outside > 0.05) {
      warning("Generator dispersion or range requires interpretation for ", scenario,
              "; SD ratio = ", signif(sd_ratio, 4), "; outside fraction = ", signif(outside, 4))
    }
    write_table(data.frame(id = dat$id, mu, outcome = y,
                           conditional_sd = mu * sqrt(variance)),
                output_group, paste0("generator-example-", scenario, ".csv"))
    data.frame(scenario, seed, n = nrow(dat), mu_min = min(mu), mu_max = max(mu),
               outcome_min = min(y), outcome_max = max(y), sd_ratio,
               fraction_outside_observed_range = outside,
               positive_support = all(y > 0), age_min = min(dat$age),
               age_max = max(dat$age), hot_days_min = min(dat$hot_days),
               hot_days_max = max(dat$hot_days), smoker_proportion = mean(dat$smoker))
  }) ->
  checks
  write_table(checks, output_group, "generator-checks.csv")
  checks
}

oracle_checks <- function(dat, output_group) {
  purrr::map_dfr(c("null", "main", "curved"), function(scenario) {
    oracle_data <- dplyr::mutate(dat, birthweight_g = generating_mean(dat, scenario))
    # This oracle represents the known mean, including curvature where declared.
    # It is used only to validate the reported functional, never as the estimator.
    oracle <- stats::lm(birthweight_g ~ hot_days * (age_c + I(age_c^2)) + smoker,
                       data = oracle_data)
    covariance <- diag(length(stats::coef(oracle)))
    dimnames(covariance) <- list(names(stats::coef(oracle)), names(stats::coef(oracle)))
    estimate_contrasts(oracle, oracle_data, covariance) |>
      dplyr::left_join(truth_contrasts(dat, scenario), by = "quantity") |>
      dplyr::transmute(scenario, quantity, truth,
                       oracle_estimate = estimate, absolute_difference = abs(estimate - truth))
  }) ->
  checks
  stopifnot(max(checks$absolute_difference) < 1e-6)
  write_table(checks, output_group, "oracle-checks.csv")
  checks
}

wilson_interval <- function(successes, n) {
  if (n == 0L) return(c(lower = NA_real_, upper = NA_real_))
  z <- stats::qnorm(0.975)
  p <- successes / n
  center <- (p + z^2 / (2 * n)) / (1 + z^2 / n)
  half <- z * sqrt(p * (1 - p) / n + z^2 / (4 * n^2)) / (1 + z^2 / n)
  c(lower = max(0, center - half), upper = min(1, center + half))
}

summarize_simulations <- function(results, planned) {
  results |>
    dplyr::group_by(scenario, quantity) |>
    dplyr::group_modify(function(rows, keys) {
      n <- nrow(rows)
      errors <- rows$estimate - rows$truth
      covered <- sum(rows$conf_low <= rows$truth & rows$conf_high >= rows$truth)
      excluded <- sum(rows$conf_low > 0 | rows$conf_high < 0)
      coverage_interval <- wilson_interval(covered, n)
      exclusion_interval <- wilson_interval(excluded, n)
      rmse <- sqrt(mean(errors^2))
      data.frame(n_planned = planned, n_successful = n, n_failed = planned - n,
                 truth = unique(rows$truth), mean_estimate = mean(rows$estimate),
                 bias = mean(errors), bias_mc_se = stats::sd(errors) / sqrt(n),
                 rmse, rmse_mc_se = stats::sd(errors^2) / (sqrt(n) * 2 * rmse),
                 coverage = covered / n, coverage_mc_low = coverage_interval[1],
                 coverage_mc_high = coverage_interval[2],
                 excludes_zero = excluded / n,
                 excludes_zero_mc_low = exclusion_interval[1],
                 excludes_zero_mc_high = exclusion_interval[2],
                 coverage_all_attempts_lower = covered / planned,
                 coverage_all_attempts_upper = (covered + planned - n) / planned,
                 excludes_zero_all_attempts_lower = excluded / planned,
                 excludes_zero_all_attempts_upper = (excluded + planned - n) / planned)
    }) |>
    dplyr::ungroup()
}
