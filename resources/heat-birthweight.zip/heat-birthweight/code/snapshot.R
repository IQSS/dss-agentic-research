# Snapshot the complete dependency closure discovered from all project source files.
# A restore builds the isolated library from this version-pinned manifest.
renv::snapshot(project = here::here(), library = .libPaths(),
               type = "implicit", prompt = FALSE)
renv::status(project = here::here(), library = .libPaths())
