#!/usr/bin/env python3
"""Compare completed R and Python outputs under the common specification."""

import csv
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
R = ROOT / "outputs/results/analysis"
PYTHON = ROOT / "independent-python/outputs"
TOLERANCE = 1e-6


def normalize(name: str) -> str:
    return {"(Intercept)": "Intercept", "I(age_c^2)": "I(age_c ** 2)"}.get(name, name)


def rows(path: Path, key: str) -> dict[str, dict[str, str]]:
    with path.open(newline="") as stream:
        records = list(csv.DictReader(stream))
    result = {normalize(row[key]): {normalize(k): v for k, v in row.items()} for row in records}
    if len(result) != len(records):
        raise ValueError(f"Duplicate comparison keys in {path.name}")
    return result


def compare() -> list[dict]:
    results = []
    original = json.loads((PYTHON / "validation.json").read_text())
    for filename in ("data/raw/births.csv", "specification.md"):
        source = ROOT / ("docs/notes/independent-implementation-specification.md"
                         if filename == "specification.md" else filename)
        a = hashlib.sha256(source.read_bytes()).hexdigest()
        b = hashlib.sha256((ROOT / "independent-python" / filename).read_bytes()).hexdigest()
        results.append({"check": filename, "agreement": a == b == original["specification_sha256" if filename == "specification.md" else "input_sha256"], "sha256": a})
    ids_a, ids_b = rows(R / "sample-ids.csv", "id"), rows(PYTHON / "sample-ids.csv", "id")
    results.append(
        {"check": "sample membership", "agreement": set(ids_a) == set(ids_b), "n": len(ids_a)}
    )
    for filename, key, columns, tolerance in [
        ("design-matrix.csv", "id", None, 0),
        ("coefficients.csv", "term", ["estimate", "std_error"], TOLERANCE),
        ("covariance.csv", "term", None, TOLERANCE),
        ("fitted-values.csv", "id", ["fitted"], TOLERANCE),
        (
            "contrasts.csv",
            "quantity",
            ["estimate", "std_error", "conf_low", "conf_high"],
            TOLERANCE,
        ),
    ]:
        a, b = rows(R / filename, key), rows(PYTHON / filename, key)
        if set(a) != set(b):
            raise ValueError(f"Record keys differ in {filename}")
        fields = columns or [field for field in next(iter(a.values())) if field != key]
        if columns is None and set(fields) != set(next(iter(b.values()))) - {key}:
            raise ValueError(f"Design or covariance terms differ in {filename}")
        maximum = max(
            abs(float(a[row][field]) - float(b[row][field])) for row in a for field in fields
        )
        results.append(
            {
                "check": filename,
                "agreement": maximum <= tolerance,
                "maximum_absolute_difference": maximum,
                "tolerance": tolerance,
            }
        )
    return results


def main() -> None:
    results = compare()
    output = ROOT / "outputs/results/verification"
    output.mkdir(parents=True, exist_ok=True)
    (output / "independent-comparison.json").write_text(json.dumps(results, indent=2) + "\n")
    report = [
        "# Independent implementation comparison",
        "",
        (
            "Both implementations started from the same specification and synthetic"
            " input file. The frozen specification is preserved in "
            "docs/notes/independent-implementation-specification.md; both hashes "
            "must also match the original Python validation record. R term names are normalized to their Python equivalents "
            "only for comparison. No numerical values are transformed."
        ),
        "",
        "| Check | Agreement | Maximum absolute difference |",
        "|---|---|---|",
    ]
    for item in results:
        difference = item.get("maximum_absolute_difference")
        report.append(
            f"| {item['check']} | {'Yes' if item['agreement'] else 'NO'} | {difference:.3g} |"
            if difference is not None
            else f"| {item['check']} | {'Yes' if item['agreement'] else 'NO'} | Exact identity |"
        )
    (output / "independent-comparison.md").write_text("\n".join(report) + "\n")
    if not all(item["agreement"] for item in results):
        raise SystemExit("Independent comparison failed; inspect the saved report.")
    print("Inputs, specification, samples, designs, and numerical results agree.")


if __name__ == "__main__":
    main()
