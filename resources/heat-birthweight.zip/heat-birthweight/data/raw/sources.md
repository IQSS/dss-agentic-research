# Input provenance

Source: entirely synthetic individual-level teaching data; no observed birth records.
Generator: code/_data-acquisition/generate-data.R; seed 20261103; 1,200 independent rows.
R version: R version 4.6.2 (2026-10-29)
Variables: data/raw/data-dictionary.md. Analysis requirements: SPECIFICATION.md.
Original file MD5: 3bd00325d15caba5aa68344e2fa20625
The checksum detects changed bytes; it does not establish scientific validity.
