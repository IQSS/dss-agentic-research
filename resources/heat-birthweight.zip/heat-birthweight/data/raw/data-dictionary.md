# Data dictionary

Each row describes one synthetic birth. All 1,200 records are complete and included in the primary analysis.

| Variable | Meaning and units | Allowed values |
|:------------------|:----------------------------------------------------|:-----------------------|
| `id` | Unique record identifier | One per birth |
| `age` | Mother’s age in years | 18–40, inclusive |
| `hot_days` | Number of hot days during the third trimester | 0–20, inclusive; the analysis permits fractional values |
| `smoker` | Maternal smoking indicator | 0 (no), 1 (yes) |
| `birthweight_g` | Baby’s birthweight in grams | Positive |

The generator draws integer ages and hot-day counts; those generation choices do not add integer restrictions to the analysis specification. `age_c` is derived as `age - 28`. Source and generation details are in [sources.md](sources.md); analysis requirements are in [SPECIFICATION.md](../../SPECIFICATION.md).
