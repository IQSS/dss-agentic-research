# Synthetic heat exposure and birthweight

This teaching project follows 1,200 invented birth records from a written specification to saved estimates, simulation checks, an independent implementation, and manuscript reporting. Its numerical results are not evidence about actual pregnancies or heat effects.

Start with `specification.md`. The main R implementation is in this folder; `independent-python/` contains a separately developed implementation of the same primary analysis. Both receive identical copies of the original data and specification. The comparison happens only after their outputs have been saved.

## Reproduce the R analysis

Use the R and package versions in `renv.lock`. `environment-setup.txt` describes restoration and platform requirements. Work in a separate copy outside a cloud-synchronized folder for an installation trial. The supplied pseudo-terminal wrapper supports macOS; adapt its `script` invocation for another operating system.

After restoring the recorded environment:

```sh
just check
just analysis
just simulation 400
just figures
```

`analysis` rebuilds the fit and contrasts. `figures` reads saved analysis and simulation outputs; it does not refit them. The simulation keeps the original covariates and generates a completely new outcome for each replicate. It uses the unchanged estimator in every world.

`code/generate-data.R` recreates the original synthetic input. The input is supplied, so ordinary reproduction does not need to run the generator. It refuses to overwrite a different existing input.

## Reproduce and compare Python

Follow `independent-python/README.md` to restore its pinned environment and run `just reproduce` inside that folder. Then, from the outer project root, run:

```sh
uv run --project independent-python --locked python code/compare-implementations.py
```

The comparison checks input/specification fingerprints, exact sample membership and design values, then coefficients, covariance, fitted values, and reported contrasts. It normalizes the two languages' labels for intercept and squared age; it does not change numerical outputs. The agreed numerical tolerance is 0.000001. Results are saved in `outputs/verification/`.

## Read the evidence

| Location | Contents |
|---|---|
| `data/raw/` | Original synthetic records and their provenance |
| `outputs/analysis/` | Saved fit, design, sample, coefficients, contrasts, and software record |
| `outputs/simulation/` | Repetition-level results, seeds, truth, uncertainty, and failure accounting |
| `outputs/validation/` | Generator, input-boundary, formula, and known-answer checks |
| `outputs/verification/` | Cross-language comparison |
| `outputs/figures/` | Figures made from the saved results |

The completed simulation has 400 repetitions in each of three worlds and no failed fits. In the curved-modifier world, the age-28 contrast is biased and its intervals under-cover the specified truth. That result is retained as a limitation of the unchanged estimator. The independent primary analyses agree within tolerance.

The scripts and checks were run on the development Mac. The lockfiles were checked, but restoring the R library on a clean machine has not been demonstrated. This package records that limitation rather than treating a successful run in an existing environment as a clean-installation test.

Keep simulation, implementation agreement, and substantive validity distinct. The synthetic study does not establish causal identification, external validity, or performance under missingness or measurement error.
