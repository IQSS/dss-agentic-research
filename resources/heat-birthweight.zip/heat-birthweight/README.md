# Synthetic heat exposure and birthweight

This teaching project follows 1,200 synthetic birth records through a written specification, saved analysis, simulation, independent implementation, and manuscript reporting. Start with [SPECIFICATION.md](SPECIFICATION.md) for the prescribed analysis and [METHODOLOGY.md](METHODOLOGY.md) for documented decisions and reasons.

## Find the files

| Location | Contents |
|:---------------------------------------|:-------------------------------------------------------------|
| `AGENTS.md`, `CLAUDE.md` | Maintained project instructions; Claude imports the same `AGENTS.md` |
| `STATUS.md`, `TASKS.md` | Current state, outstanding work, and checked completions |
| `data/raw/`, `data/processed/` | Original synthetic records and data dictionary; checked analysis input |
| `code/_startup/`, `code/` | Shared setup/functions; independently runnable analysis and check scripts |
| `code/_data-acquisition/`, `code/_final/` | Synthetic input generator; figure assembly |
| `outputs/models/`, `outputs/results/` | Saved fit/covariance; analysis, simulation, validation, and comparison tables |
| `outputs/figures/working/`, `outputs/figures/final/` | Generator diagnostics; figures from saved analysis results |
| `manuscript/` | Illustrative results passage linked to saved estimates |
| `docs/notes/` | Simulation specification, frozen original specification, and original comparison reports |
| `independent-python/` | Preserved, separately developed implementation with its own original layout, inputs, and results |

Only folders used by this example are needed. There is no installed project skill to index: project instructions are in `AGENTS.md`, and a skill would have its own `SKILL.md`.

## Reproduce the R analysis

Use the R and package versions in `renv.lock`. `environment-setup.txt` describes restoration and platform requirements. Use a separate copy outside a cloud-synchronized folder for an installation trial. The supplied pseudo-terminal wrapper supports macOS; adapt its `script` invocation for another operating system.

After restoring the recorded environment:

```sh
just check
just analysis
just simulation 400
just figures
just compare
```

`analysis` rebuilds the fit and contrasts. `figures` reads saved analysis and simulation results without refitting. A shorter `just simulation 2` checks execution in all three scenarios and writes to `outputs/results/simulation-smoke/`, leaving the full simulation intact.

`code/_data-acquisition/generate-data.R` recreates the supplied input. Ordinary reproduction does not need it. It refuses to overwrite a different input.

## Understand the independent check

Two fresh agents originally received identical data and specification files without access to each other’s code or results. The original R-side specification is preserved unchanged in `docs/notes/independent-implementation-specification.md`; the Python copy remains at `independent-python/specification.md`. The current root specification records the same scientific requirements and the updated file layout.

Follow `independent-python/README.md` to restore its pinned environment and reproduce its results. Then run `just compare` from this outer project. The comparison checks original input/specification hashes against both copies and the original Python validation record, exact sample membership and design values, then numerical results within 0.000001. It normalizes only language-specific term names. Reports go in `outputs/results/verification/`; the original reports remain in `docs/notes/`.

## Completed checks and remaining limits

The supplied full simulation has 400 repetitions in each of three scenarios and no failed fits. The curved scenario exposes bias and poor interval coverage for the age-28 contrast under the unchanged estimator. The independent primary analyses agree within tolerance.

The scripts and checks were run on the development Mac. Restoring the R library on a clean machine has not been demonstrated. See `docs/notes/layout-validation.md` for checks of the reorganized download. Synthetic calculations do not establish causal identification, external validity, or performance under missingness or measurement error.
