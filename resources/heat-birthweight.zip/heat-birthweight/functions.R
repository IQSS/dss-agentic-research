load_pkgs <- function(...) {
  pkgs <- c(...)
  invisible(lapply(pkgs, library, character.only = TRUE))
}

validate_births <- function(dat) {
  required <- c("id", "age", "hot_days", "smoker", "birthweight_g")
  stopifnot(all(required %in% names(dat)), nrow(dat) == 1200L,
            !anyNA(dat[required]), !anyDuplicated(dat$id),
            all(vapply(dat[required], function(x) all(is.finite(x)), logical(1))),
            all(dat$age >= 18 & dat$age <= 40),
            all(dat$hot_days >= 0 & dat$hot_days <= 20),
            all(dat$smoker %in% c(0, 1)), all(dat$birthweight_g > 0))
  invisible(dat)
}

read_births <- function() {
  readr::read_csv(here::here("data", "raw", "births.csv"),
                 show_col_types = FALSE) |>
    as.data.frame() ->
  dat
  validate_births(dat)
  dplyr::mutate(dat, age_c = age - 28)
}

fit_model <- function(dat) {
  fit <- stats::lm(birthweight_g ~ hot_days + age_c + I(age_c^2) +
                     smoker + hot_days:age_c, data = dat, na.action = na.fail)
  stopifnot(fit$rank == 6L, all(is.finite(stats::coef(fit))))
  fit
}

hc3_covariance <- function(fit) {
  covariance <- sandwich::vcovHC(fit, type = "HC3")
  stopifnot(all(is.finite(covariance)), all(diag(covariance) > 0))
  covariance
}

standardization_rows <- function(dat) {
  # Each age-specific group retains every observed smoking value.
  marginaleffects::datagrid(newdata = dat, grid_type = "counterfactual",
                           age = c(22, 28, 36)) |>
    dplyr::mutate(age_c = age - 28, quantity = paste0("age_", age)) |>
    dplyr::bind_rows(dplyr::mutate(dat, quantity = "sample")) |>
    as.data.frame()
}

estimate_contrasts <- function(fit, dat, covariance = hc3_covariance(fit)) {
  counterfactual_rows <- standardization_rows(dat)
  marginaleffects::avg_comparisons(
    fit, newdata = counterfactual_rows, variables = list(hot_days = c(5, 10)),
    by = "quantity", comparison = "difference", vcov = covariance,
    conf_level = 0.95, df = Inf, numderiv = list("fdcenter", eps = 0.001)
  ) |>
    as.data.frame() |>
    dplyr::transmute(quantity, estimate, std_error = std.error,
                     conf_low = conf.low, conf_high = conf.high) |>
    dplyr::arrange(match(quantity, c("sample", "age_22", "age_28", "age_36"))) ->
  contrasts
  stopifnot(nrow(contrasts) == 4L,
            all(is.finite(as.matrix(contrasts[-1]))),
            max(abs(contrasts$conf_low - contrasts$estimate +
                      stats::qnorm(0.975) * contrasts$std_error)) < 1e-9)
  contrasts
}

write_table <- function(x, ...) {
  path <- here::here("outputs", ...)
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  readr::write_csv(x, path, na = "NA")
  invisible(path)
}

software_versions <- function() {
  packages <- c("R", "renv", "marginaleffects", "sandwich", "ggplot2",
                "dplyr", "purrr", "readr", "here")
  versions <- c(as.character(getRversion()),
                vapply(packages[-1], function(p) as.character(utils::packageVersion(p)),
                       character(1)))
  data.frame(software = packages, version = versions)
}
