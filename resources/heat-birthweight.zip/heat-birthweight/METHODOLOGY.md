# Scientific decisions

Current requirements: [SPECIFICATION.md](SPECIFICATION.md). New decisions go above older entries. Routine progress belongs in `TASKS.md`.

## 2026-11-10 — Separate current requirements from the retained run specification

The guide now uses a current scientific specification and a dated decision log for paper projects. Reorganized this example to demonstrate that layout, without changing its scientific requirements or saved numerical results. Moved the original specification unchanged to `docs/notes/independent-implementation-specification.md`; the current specification links to it and to the extracted simulation requirements. This preserves what the independent implementers actually received.

## 2026-11-10 — Retrospective summary of documented analysis decisions

This entry summarizes the supplied specification, code checks, and saved reports; it is not a reconstruction of the dates on which the original decisions were made.

- Report sample-standardized and age-specific 10-minus-5-hot-day contrasts. With an age interaction, the heat coefficient alone does not supply every requested contrast.
- Use quadratic age, the linear heat-by-age interaction, smoking adjustment, HC3 covariance, and normal 95% intervals as prescribed. Python’s default t intervals were replaced by the specified normal intervals. R input-rule corrections restored the specified age range and removed an unrequested integer restriction on hot days. These repairs did not change the scientific requirements or the saved estimates.
- Keep the same estimator across the null, main, and curved simulation scenarios. The curved scenario deliberately exceeds its interaction form; its poor age-28 performance remains a result to examine, not a reason to silently replace the estimator.

Evidence: [frozen specification](docs/notes/independent-implementation-specification.md), [original comparison](docs/notes/original-independent-comparison.md), and the saved validation and simulation outputs. No new methodological revision is approved by this summary.
