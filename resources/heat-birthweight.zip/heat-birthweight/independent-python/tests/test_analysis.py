"""Analytic checks for the specified prediction contrasts and HC3 estimator."""

from itertools import product

import numpy as np
import pandas as pd
import pytest
import statsmodels.api as sm
from analysis import (
    NORMAL_CRITICAL,
    QUANTITIES,
    TERMS,
    contrast_gradient,
    design_matrix,
    explicit_hc3,
    fit_model,
    summarize_contrasts,
    validate_data,
)


@pytest.fixture
def known_design() -> pd.DataFrame:
    rows = list(product([22.0, 28.0, 36.0], [0.0, 5.0, 10.0], [0, 1]))
    frame = pd.DataFrame(rows, columns=["age", "hot_days", "smoker"])
    frame.insert(0, "id", np.arange(1, len(frame) + 1))
    frame["birthweight_g"] = 3000.0
    return frame


def test_hc3_intercept_only_has_known_variance() -> None:
    # Mean = 2.5; squared residuals sum to 5; every leverage equals 1/4.
    # HC3 variance = 5 / ((1 - 1/4)^2 * 4^2) = 5/9.
    x = np.ones((4, 1))
    y = np.array([1.0, 2.0, 3.0, 4.0])
    fitted = sm.OLS(y, x).fit(cov_type="HC3", use_t=False)
    assert fitted.params[0] == pytest.approx(2.5, abs=1e-14)
    assert fitted.cov_params()[0, 0] == pytest.approx(5 / 9, abs=1e-14)
    assert explicit_hc3(x, y - 2.5)[0, 0] == pytest.approx(5 / 9, abs=1e-14)


@pytest.mark.parametrize("age", [None, 22, 28, 36])
def test_counterfactual_gradient_has_analytic_form(known_design: pd.DataFrame, age: float) -> None:
    centered_age = known_design["age"].mean() - 28 if age is None else age - 28
    np.testing.assert_allclose(
        contrast_gradient(known_design, age),
        [0, 5, 0, 0, 0, 5 * centered_age],
        rtol=0,
        atol=1e-14,
    )


@pytest.mark.parametrize("hot_slope,interaction", [(0.0, 0.0), (-3.0, 0.0), (-3.0, 0.5)])
def test_predictions_recover_known_contrasts(
    known_design: pd.DataFrame, hot_slope: float, interaction: float
) -> None:
    beta = np.array([3500.0, hot_slope, 5.0, -1.4, -120.0, interaction])
    known_design["birthweight_g"] = design_matrix(known_design) @ beta
    fitted = fit_model(known_design)
    np.testing.assert_allclose(fitted.params, beta, atol=1e-10, rtol=0)
    summaries, _ = summarize_contrasts(known_design, fitted.params.to_numpy(), np.eye(6))
    for row in summaries.itertuples():
        age = QUANTITIES[row.quantity]
        center = known_design["age"].mean() - 28 if age is None else age - 28
        assert row.estimate == pytest.approx(5 * (hot_slope + interaction * center), abs=1e-10)


def test_delta_method_uses_covariance_and_normal_critical(known_design: pd.DataFrame) -> None:
    beta = np.array([3500, -3, 5, -1.4, -120, 0.5])
    covariance = np.diag([1.0, 4.0, 1.0, 1.0, 1.0, 0.25])
    covariance[1, 5] = covariance[5, 1] = -0.5
    result, _ = summarize_contrasts(known_design, beta, covariance)
    row = result.set_index("quantity").loc["age_36"]
    # At age 36: gradient is (0, 5, 0, 0, 0, 40).
    expected_se = np.sqrt(25 * 4 + 1600 * 0.25 + 2 * 5 * 40 * -0.5)
    assert row.estimate == pytest.approx(5.0, abs=1e-14)
    assert row.std_error == pytest.approx(expected_se, abs=1e-14)
    assert pytest.approx(1.959963984540054, abs=1e-15) == NORMAL_CRITICAL
    assert row.conf_low == pytest.approx(5 - 1.959963984540054 * expected_se, abs=1e-12)
    assert row.conf_high == pytest.approx(5 + 1.959963984540054 * expected_se, abs=1e-12)


def test_design_recomputes_age_terms(known_design: pd.DataFrame) -> None:
    replaced = known_design.assign(age=36, age_c=-99)
    matrix = design_matrix(replaced)
    np.testing.assert_array_equal(matrix["age_c"], 8)
    np.testing.assert_array_equal(matrix["I(age_c ** 2)"], 64)
    np.testing.assert_array_equal(matrix["hot_days:age_c"], replaced["hot_days"] * 8)
    assert tuple(matrix.columns) == TERMS


def test_smoking_values_and_row_order_do_not_change_the_contrast(
    known_design: pd.DataFrame,
) -> None:
    expected = contrast_gradient(known_design)
    altered = known_design.assign(smoker=1).iloc[::-1]
    np.testing.assert_allclose(contrast_gradient(altered), expected, rtol=0, atol=1e-14)


@pytest.mark.parametrize(
    "column,value",
    [
        ("age", 17),
        ("age", 41),
        ("hot_days", -1),
        ("hot_days", 21),
        ("smoker", 2),
        ("birthweight_g", 0),
        ("birthweight_g", np.inf),
        ("age", np.nan),
    ],
)
def test_invalid_rows_fail_without_dropping(
    known_design: pd.DataFrame, column: str, value: float
) -> None:
    invalid = known_design.copy()
    invalid.loc[0, column] = value
    with pytest.raises(ValueError):
        validate_data(invalid, expected_rows=len(invalid))


def test_duplicate_ids_fail(known_design: pd.DataFrame) -> None:
    known_design.loc[1, "id"] = known_design.loc[0, "id"]
    with pytest.raises(ValueError, match="unique"):
        validate_data(known_design, expected_rows=len(known_design))


def test_wrong_sample_count_fails(known_design: pd.DataFrame) -> None:
    with pytest.raises(ValueError, match="1200"):
        validate_data(known_design)


def test_valid_sample_preserves_ids(known_design: pd.DataFrame) -> None:
    valid = validate_data(known_design, expected_rows=len(known_design))
    pd.testing.assert_series_equal(valid["id"], known_design["id"])


def test_rank_deficiency_fails(known_design: pd.DataFrame) -> None:
    with pytest.raises(ValueError, match="full rank"):
        fit_model(known_design.assign(hot_days=0))
