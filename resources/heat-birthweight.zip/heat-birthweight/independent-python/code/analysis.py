"""Fit the specified OLS/HC3 analysis of invented birth records."""

import hashlib
import importlib.metadata
import json
import platform
from pathlib import Path

import marginaleffects as me
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf
from numpy.typing import NDArray
from scipy.stats import norm
from statsmodels.regression.linear_model import RegressionResultsWrapper

PROJECT_ROOT: Path = Path(__file__).resolve().parent.parent
FORMULA: str = "birthweight_g ~ hot_days + age_c + I(age_c ** 2) + smoker + hot_days:age_c"
TERMS: tuple[str, ...] = (
    "Intercept",
    "hot_days",
    "age_c",
    "I(age_c ** 2)",
    "smoker",
    "hot_days:age_c",
)
QUANTITIES: dict[str, float | None] = {"sample": None, "age_22": 22, "age_28": 28, "age_36": 36}
NORMAL_CRITICAL: float = float(norm.ppf(0.975))
FLOAT_FORMAT: str = "%.17g"


def validate_data(data: pd.DataFrame, expected_rows: int = 1200) -> pd.DataFrame:
    """Reject invalid inputs without removing or replacing records."""
    required = ["id", "age", "hot_days", "smoker", "birthweight_g"]
    if list(data.columns) != required:
        raise ValueError(f"Expected columns in this order: {required}")
    if len(data) != expected_rows:
        raise ValueError(f"Expected {expected_rows} rows; received {len(data)}")
    if data[required].isna().any().any():
        raise ValueError("Required inputs contain missing values")
    if data["id"].duplicated().any():
        raise ValueError("Record ids must be unique")
    numeric = data[["age", "hot_days", "smoker", "birthweight_g"]]
    if not all(pd.api.types.is_numeric_dtype(dtype) for dtype in numeric.dtypes):
        raise ValueError("Analysis variables must be numeric")
    if not np.isfinite(numeric.to_numpy(dtype=float)).all():
        raise ValueError("Analysis variables must be finite")
    if not data["age"].between(18, 40, inclusive="both").all():
        raise ValueError("Age must be between 18 and 40 inclusive")
    if not data["hot_days"].between(0, 20, inclusive="both").all():
        raise ValueError("Hot days must be between 0 and 20 inclusive")
    if not data["smoker"].isin([0, 1]).all():
        raise ValueError("Smoker must equal 0 or 1")
    if not data["birthweight_g"].gt(0).all():
        raise ValueError("Birthweight must be positive")
    return data.assign(age_c=data["age"] - 28)


def design_matrix(data: pd.DataFrame) -> pd.DataFrame:
    """Build all transformed terms afresh from age and exposure."""
    age_c = data["age"] - 28
    return pd.DataFrame(
        {
            "Intercept": np.ones(len(data)),
            "hot_days": data["hot_days"],
            "age_c": age_c,
            "I(age_c ** 2)": age_c**2,
            "smoker": data["smoker"],
            "hot_days:age_c": data["hot_days"] * age_c,
        },
        index=data.index,
        dtype=float,
    )


def fit_model(data: pd.DataFrame) -> RegressionResultsWrapper:
    """Fit the six specified terms with an HC3 covariance and normal inference."""
    model_data = data.assign(age_c=data["age"] - 28)
    model = smf.ols(FORMULA, data=model_data, missing="raise")
    if tuple(model.exog_names) != TERMS:
        raise ValueError("Fitted design terms differ from the specification")
    if np.linalg.matrix_rank(model.exog) != len(TERMS):
        raise ValueError("The specified design matrix is not full rank")
    np.testing.assert_allclose(model.exog, design_matrix(data), rtol=0, atol=0)
    return model.fit(cov_type="HC3", use_t=False)


def contrast_gradient(data: pd.DataFrame, age: float | None = None) -> NDArray[np.float64]:
    """Average the 10-minus-5 prediction design differences over every input row."""
    reference = data.copy()
    if age is not None:
        reference["age"] = age
    high = design_matrix(reference.assign(hot_days=10))
    low = design_matrix(reference.assign(hot_days=5))
    return (high - low).to_numpy().mean(axis=0)


def summarize_contrasts(
    data: pd.DataFrame, coefficients: NDArray[np.float64], covariance: NDArray[np.float64]
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Apply the exact linear delta method to sample-standardized predictions."""
    summaries = []
    gradients = []
    for quantity, age in QUANTITIES.items():
        gradient = contrast_gradient(data, age)
        estimate = float(gradient @ coefficients)
        variance = float(gradient @ covariance @ gradient)
        if not np.isfinite(variance) or variance < 0:
            raise ValueError(f"Invalid contrast variance for {quantity}")
        std_error = float(np.sqrt(variance))
        summaries.append(
            {
                "quantity": quantity,
                "estimate": estimate,
                "std_error": std_error,
                "conf_low": estimate - NORMAL_CRITICAL * std_error,
                "conf_high": estimate + NORMAL_CRITICAL * std_error,
            }
        )
        gradients.append({"quantity": quantity, **dict(zip(TERMS, gradient, strict=True))})
    return pd.DataFrame(summaries), pd.DataFrame(gradients)


def explicit_hc3(design: NDArray[np.float64], residuals: NDArray[np.float64]) -> NDArray:
    """Independently check HC3 using its defining sandwich expression."""
    inverse = np.linalg.inv(design.T @ design)
    leverage = np.einsum("ij,jk,ik->i", design, inverse, design)
    if np.any(leverage >= 1):
        raise ValueError("HC3 is undefined when leverage reaches one")
    adjusted_squares = residuals**2 / (1 - leverage) ** 2
    meat = design.T @ (design * adjusted_squares[:, None])
    return inverse @ meat @ inverse


def check_marginaleffects(data: pd.DataFrame, fit: RegressionResultsWrapper) -> pd.DataFrame:
    """Retain the package comparison and its native t intervals for an API audit.

    marginaleffects 0.6.1 uses residual-df t intervals for statsmodels OLS,
    including fits with use_t=False. Its API has no degrees-of-freedom override.
    The reported analysis therefore uses exact linear prediction contrasts and
    the specified normal critical value in summarize_contrasts.
    """
    rows = []
    for quantity, age in QUANTITIES.items():
        reference = data.copy()
        if age is not None:
            reference["age"] = age
        reference["age_c"] = reference["age"] - 28
        result = me.avg_comparisons(
            fit,
            variables={"hot_days": [5, 10]},
            newdata=reference,
            comparison="difference",
            vcov="HC3",
            conf_level=0.95,
        ).to_pandas()
        if len(result) != 1:
            raise ValueError("Expected a single standardized comparison")
        row = result.iloc[0]
        rows.append(
            {
                "quantity": quantity,
                "estimate": float(row["estimate"]),
                "std_error": float(row["std_error"]),
                "native_conf_low": float(row["conf_low"]),
                "native_conf_high": float(row["conf_high"]),
            }
        )
    return pd.DataFrame(rows)


def save_csv(frame: pd.DataFrame, path: Path) -> None:
    frame.to_csv(path, index=False, float_format=FLOAT_FORMAT)


def main() -> None:
    data_path = PROJECT_ROOT / "data" / "raw" / "births.csv"
    data = validate_data(pd.read_csv(data_path))
    fit = fit_model(data)
    coefficients = fit.params.to_numpy()
    covariance = fit.cov_params().to_numpy()
    contrasts, gradients = summarize_contrasts(data, coefficients, covariance)
    hc3_check = explicit_hc3(fit.model.exog, fit.resid.to_numpy())
    np.testing.assert_allclose(covariance, hc3_check, rtol=1e-10, atol=1e-8)
    package_check = check_marginaleffects(data, fit)
    np.testing.assert_allclose(
        contrasts[["estimate", "std_error"]],
        package_check[["estimate", "std_error"]],
        rtol=0,
        atol=1e-6,
    )

    output = PROJECT_ROOT / "outputs"
    output.mkdir(exist_ok=True)
    save_csv(contrasts, output / "contrasts.csv")
    save_csv(data[["id"]], output / "sample-ids.csv")
    coefficient_table = pd.DataFrame(
        {
            "term": TERMS,
            "estimate": coefficients,
            "std_error": fit.bse.to_numpy(),
            "conf_low": coefficients - NORMAL_CRITICAL * fit.bse.to_numpy(),
            "conf_high": coefficients + NORMAL_CRITICAL * fit.bse.to_numpy(),
        }
    )
    save_csv(coefficient_table, output / "coefficients.csv")
    save_csv(fit.cov_params().rename_axis("term").reset_index(), output / "covariance.csv")
    save_csv(data[["id"]].assign(fitted=fit.fittedvalues.to_numpy()), output / "fitted-values.csv")
    save_csv(
        design_matrix(data).assign(id=data["id"])[["id", *TERMS]], output / "design-matrix.csv"
    )
    save_csv(gradients, output / "contrast-gradients.csv")
    save_csv(package_check, output / "marginaleffects-check.csv")
    fit.save(output / "fitted-model.pkl", remove_data=False)
    reloaded = sm.load(output / "fitted-model.pkl")
    np.testing.assert_allclose(reloaded.params, coefficients, rtol=0, atol=0)
    np.testing.assert_allclose(reloaded.cov_params(), covariance, rtol=0, atol=0)

    validation = {
        "input_sha256": hashlib.sha256(data_path.read_bytes()).hexdigest(),
        "specification_sha256": hashlib.sha256(
            (PROJECT_ROOT / "specification.md").read_bytes()
        ).hexdigest(),
        "row_count": len(data),
        "unique_ids": int(data["id"].nunique()),
        "age_range": [float(data["age"].min()), float(data["age"].max())],
        "hot_days_range": [float(data["hot_days"].min()), float(data["hot_days"].max())],
        "design_terms": list(TERMS),
        "design_rank": int(np.linalg.matrix_rank(fit.model.exog)),
        "formula": FORMULA,
        "covariance": "HC3",
        "confidence_level": 0.95,
        "critical_value": NORMAL_CRITICAL,
        "contrast_direction": "10 minus 5 hot days",
        "hc3_formula_check_max_abs_difference": float(np.max(np.abs(covariance - hc3_check))),
        "marginaleffects_estimate_check_max_abs_difference": float(
            np.max(np.abs(contrasts["estimate"] - package_check["estimate"]))
        ),
        "marginaleffects_se_check_max_abs_difference": float(
            np.max(np.abs(contrasts["std_error"] - package_check["std_error"]))
        ),
        "saved_model_roundtrip": "passed",
        "uncertainty_method": "exact linear delta method; standard normal intervals",
        "marginaleffects_interval_limitation": (
            "Version 0.6.1 uses residual-df t intervals despite use_t=False. "
            "Native intervals are saved only as an API audit, not as reported intervals."
        ),
        "ambiguities_resolved": [
            "Age range is 18 through 40 inclusive.",
            "Hot days uses the specified bounds without an integer-only restriction.",
            "All records receive equal weight in each standardized contrast.",
        ],
        "scope": "Fixed wholly synthetic sample; no population causal interpretation.",
        "independence": (
            "Implementation constructed from the specification and original CSV without reading "
            "another implementation or its results; this is procedural separation."
        ),
    }
    (output / "validation.json").write_text(json.dumps(validation, indent=2) + "\n")
    versions = {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "packages": dict(
            sorted(
                (distribution.metadata["Name"], distribution.version)
                for distribution in importlib.metadata.distributions()
            )
        ),
    }
    (output / "software-versions.json").write_text(json.dumps(versions, indent=2) + "\n")
    print(f"Saved four standardized contrasts for all {len(data)} synthetic records.")
    print(contrasts.to_string(index=False))


if __name__ == "__main__":
    main()
