# Synthetic heat exposure and birthweight: analysis specification

This teaching project uses invented individual records. No numerical result is evidence about real pregnancies, maternal smoking, or heat exposure.

## Data and analysis sample

Use `data/raw/births.csv`, with one independent record per `id`. Variables are `age` (18–40 years inclusive), `hot_days` (0–20 days), `smoker` (0 or 1), and `birthweight_g` (positive grams). All 1,200 records belong in the primary analysis. Verify unique ids, valid ranges, and complete inputs. Fail if the supplied file violates these requirements; do not drop rows or invent replacements.

Define `age_c = age - 28`. Fit ordinary least squares with an intercept and the following terms, in this order: `hot_days`, `age_c`, `age_c^2`, `smoker`, and `hot_days * age_c`. The model is equivalent to `birthweight_g ~ hot_days * age_c + I(age_c^2) + smoker` in R. Use the HC3 covariance estimator, with the squared residual divided by the square of one minus the leverage for each observation. Preserve the fitted model and its coefficient/covariance estimates.

## Quantities to report

The primary estimand is the mean difference in predicted birthweight at 10 versus 5 hot days, averaging over the sample's observed age and smoking distribution. Report it as a sample-standardized contrast, in grams, with direction 10 minus 5.

Also report that contrast at ages 22, 28, and 36. For each age, replace age in every row with that age and preserve each row's smoking value. Recalculate `age_c` and its squared term from the replaced age. Compare predictions at 10 and 5 hot days and average across those rows. These are age-specific standardized contrasts; they are not model coefficients.

Use delta-method standard errors from the HC3 covariance matrix and two-sided 95% confidence intervals with the standard normal critical value. Report full-precision results before formatting for a manuscript. All contrasts concern this synthetic sample; do not label them population causal effects.

Write `contrasts.csv` with columns `quantity`, `estimate`, `std_error`, `conf_low`, `conf_high`, using quantities `sample`, `age_22`, `age_28`, and `age_36`. Also write sample ids, the coefficient table, the covariance matrix with named rows/columns, fitted values by id, and a software-version record. Expose a saved command to reproduce those outputs.

## Independent implementation

Implement from this specification and the original CSV. Do not read another implementation, its intermediate files, or its results. Record any ambiguity and resolve it explicitly before comparing outputs. Once each implementation is complete, compare sample ids and design terms before fitted values and contrasts. Use an absolute tolerance of 1e-6 grams for estimates and interval bounds and 1e-6 for standard errors. Investigate discrepancies rather than changing the specification or tolerance to obtain agreement.

## Simulation extension

The simulation keeps the supplied CSV covariate rows fixed and replaces all outcomes in every replicate. Do not generate a different covariate design or use the supplied birthweight values in the simulation. The mean is `3500 - 1.4 * age_c^2 - 140 * smoker + hot_days * slope(age_c)`.

- Null: `slope = 0`.
- Main: `slope = -8 + 0.5 * age_c`.
- Curved modifier: `slope = -8 + 0.5 * age_c + 0.12 * age_c^2`.

Generate a positive outcome as `mu * exp(0.10 * z - 0.10^2 / 2)`, with an independent standard normal `z` for each row. Its conditional expectation is `mu`; variance increases with the mean. Check the generator's positive support, intended conditional moments, and covariate/exposure ranges before repeated estimation. The curved-modifier world intentionally exceeds the estimator's specified interaction form.

For each world, repeat generation and estimation 400 times with recorded seeds. Report bias, root mean squared error, 95% interval coverage, and the proportion of intervals excluding zero for every reported quantity. Report binomial Monte Carlo uncertainty for the rates, including appropriate nonzero uncertainty when the observed rate is zero or one. Save failed runs explicitly and retain them in the accounting. Calculate truth from the declared generating mean, independently of the fitted model. Do not change the primary estimator after seeing a failed scenario.

The exercise assesses this procedure on a fixed synthetic design, with error-free measured exposures and no missing data. It does not test identification assumptions, population transport, exposure measurement error, or all possible outcome distributions.
