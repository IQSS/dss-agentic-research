# Synthetic birthweight analysis in Python

This example analyzes 1,200 invented records under the fixed model and estimands in `specification.md`. Every result concerns this synthetic sample. The numbers are not evidence about real pregnancies, smoking, or heat exposure.

Install [uv](https://docs.astral.sh/uv/) and [just](https://just.systems/), then run these commands from this directory:

```sh
just setup
just reproduce
```

`just check` runs the analytic tests and source checks. `just analyze` regenerates the analysis outputs. Python is pinned in `.python-version`; exact direct dependencies and the full dependency closure are recorded in `pyproject.toml` and `uv.lock`. The lockfile retains Polars 1.x because `marginaleffects` 0.6.1 uses numeric type checks that are incompatible with Polars 2.x.

The analysis retains every input row or fails. It checks the supplied age bounds of 18–40 years, exposure bounds of 0–20 days, binary smoking values, positive birthweight, complete finite inputs, and unique ids. It imposes no additional integer-only exposure restriction. Each contrast weights all 1,200 records equally.

The OLS design has an intercept, hot days, age centered at 28, centered age squared, smoking, and the interaction of hot days with centered age. HC3 uses squared residuals divided by squared one-minus-leverage. Predictions compare 10 with 5 hot days, preserving each record's smoking status. The sample contrast preserves observed ages; the other three replace every age with 22, 28, or 36 and recalculate the age terms.

For a linear model, the average difference between the two design matrices is the exact gradient of the standardized prediction contrast. The reported standard error is the square root of that gradient multiplied by the HC3 covariance matrix and its transpose. Confidence limits use the standard normal 0.975 quantile.

[`marginaleffects.avg_comparisons`](https://marginaleffects.com/man/python/comparisons.html) independently checks the four estimated comparisons and HC3 standard errors. Version 0.6.1 uses residual-degrees-of-freedom t critical values for statsmodels OLS, including fits with `use_t=False`, and exposes no degrees-of-freedom override in this API. The analysis therefore calculates the required normal intervals directly from prediction contrasts and HC3 covariance. It saves the package's native intervals separately for inspection; those are not the reported confidence intervals.

The `outputs/` directory contains:

| File | Contents |
|---|---|
| `contrasts.csv` | Four full-precision estimates, standard errors, and normal 95% confidence limits |
| `sample-ids.csv` | All analysis ids, in source order |
| `coefficients.csv` | Six coefficients with HC3 standard errors and normal intervals |
| `covariance.csv` | Named HC3 covariance matrix |
| `fitted-values.csv` | Fitted birthweight by id |
| `design-matrix.csv` | Six design columns by id |
| `contrast-gradients.csv` | Average 10-minus-5 design differences |
| `fitted-model.pkl` | Saved statsmodels fit, including data and covariance |
| `marginaleffects-check.csv` | Package comparisons, standard errors, and native t intervals |
| `validation.json` | Input/specification hashes, sample checks, and numerical checks |
| `software-versions.json` | Interpreter and installed package versions |

CSV floats use 17 significant digits. Load the saved model with `statsmodels.api.load` in the pinned environment. As with all Python pickle files, only load a model file you trust.

Analytic tests cover an intercept-only model with HC3 variance exactly 5/9, known coefficients and prediction contrasts, zero exposure effects, interaction-free effects, covariance contributions, transformed-age recalculation, invalid inputs, and rank deficiency. They check implementation, not real-world identification assumptions. This implementation was developed from the specification and original CSV without consulting another implementation or its results; that establishes procedural separation only.
