# Project tasks

## To do

- Test restoration of the recorded R environment in a clean environment; record the actual platform, commands, and result.
- Review the example alongside the guide chapters. Any new scientific analysis requires a decision and specification update before implementation.

## In progress

None.

## Done

- 2026-11-10: Reorganized code passed data/analysis checks, a two-repetition-per-scenario smoke test, figure building, and comparison with preserved Python results in a scratch copy. See `docs/notes/layout-validation.md`.

- 2026-11-10: Added populated current specification, scientific decision log, instructions, status, and this task record; reorganized files into the paper layout while retaining the frozen independent-analysis inputs.
- Recorded retrospectively on 2026-11-10: Existing saved artifacts establish the completed primary analysis, 400 repetitions in each of three simulation scenarios, input-rule checks, and independent R/Python comparison. Original run dates are not inferred here.
