# Simulation specification

These requirements are copied from the original independent-analysis specification. Moving them into this linked file does not change the completed simulation. The current primary analysis is prescribed in [SPECIFICATION.md](../../SPECIFICATION.md).


The simulation keeps the supplied CSV covariate rows fixed and replaces all outcomes in every replicate. Do not generate a different covariate design or use the supplied birthweight values in the simulation. The mean is `3500 - 1.4 * age_c^2 - 140 * smoker + hot_days * slope(age_c)`.

- Null: `slope = 0`.
- Main: `slope = -8 + 0.5 * age_c`.
- Curved modifier: `slope = -8 + 0.5 * age_c + 0.12 * age_c^2`.

Generate a positive outcome as `mu * exp(0.10 * z - 0.10^2 / 2)`, with an independent standard normal `z` for each row. Its conditional expectation is `mu`; variance increases with the mean. Check the generator's positive support, intended conditional moments, and covariate/exposure ranges before repeated estimation. The curved-modifier world intentionally exceeds the estimator's specified interaction form.

For each world, repeat generation and estimation 400 times with recorded seeds. Report bias, root mean squared error, 95% interval coverage, and the proportion of intervals excluding zero for every reported quantity. Report binomial Monte Carlo uncertainty for the rates, including appropriate nonzero uncertainty when the observed rate is zero or one. Save failed runs explicitly and retain them in the accounting. Calculate truth from the declared generating mean, independently of the fitted model. Do not change the primary estimator after seeing a failed scenario.

The exercise assesses this procedure on a fixed synthetic design, with error-free measured exposures and no missing data. It does not test identification assumptions, population transport, exposure measurement error, or all possible outcome distributions.
