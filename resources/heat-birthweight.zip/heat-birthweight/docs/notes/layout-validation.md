# Paper-layout validation

Checked November 10, 2026 in a separate copy under `/tmp`, using the existing development environment on macOS.

- `just check`: input boundaries, design, oracle, HC3, and contrast checks passed.
- `just analysis`: primary fit and reported contrasts rebuilt; the saved numerical CSV tables matched the pre-migration tables byte-for-byte.
- `just simulation 2`: two repetitions in each of three scenarios completed through the same simulation code, with results in a separate smoke-test directory.
- `just figures`: four figures rebuilt from saved analysis and full-simulation results.
- `just compare`: original input/specification hashes, exact sample/design comparisons, and numerical tolerances passed against the preserved independent Python outputs.
- Original data, frozen independent specification, Python implementation/results, and saved R analysis/simulation/validation artifacts were checked against a pre-migration archive and retained unchanged.

The full 400-repetition simulation was preserved rather than rerun for this file-layout change. The Python analysis was not rebuilt in this check; its preserved results were compared with the rerun R analysis. These checks do not demonstrate clean-machine restoration of the R environment.
