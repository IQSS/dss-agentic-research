# Illustrative results

In the heat-and-birthweight example, the `sample` row in `outputs/results/analysis/contrasts.csv` provides the estimate and confidence interval reported below.

> In the synthetic sample, the estimated mean birthweight difference between ten and five hot days of maternal exposure during the third trimester was -31.6 g (95% confidence interval -74.3 to 11.0 g), standardized over the sample's maternal age and smoking distribution.

The saved results retain full precision; the manuscript rounds them for presentation. The agent should check that the sentence describes the comparison and sample represented by the selected row.
