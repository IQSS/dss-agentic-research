# Project instructions

This is a fully synthetic teaching study. Read `STATUS.md` and `TASKS.md` to resume work. Follow `SPECIFICATION.md` when implementing or checking the analysis; consult `METHODOLOGY.md` for the decisions and reasons. Use project-relative paths anchored by `.here`.

- Preserve `data/raw/births.csv` and the frozen original specification in `docs/notes/independent-implementation-specification.md`.
- Keep the primary estimator, sample rules, reported contrasts, and comparison tolerance as specified. Report ambiguities rather than making scientific choices silently.
- Use the commands in `justfile`. `bin/rscript-pty` supplies the pseudo-terminal required for R runs from agents on this Mac.
- Shared R setup/functions belong in `code/_startup/`; independent analysis steps sit directly in `code/`. Save outputs in the locations prescribed by the specification.
- `independent-python/` is a preserved, separately developed implementation. Do not use its code or results to claim a new independent implementation. Completed results may be read for comparison.
- After checking work, maintain `TASKS.md` and the short `STATUS.md`. After an approved scientific change, also rewrite the affected `SPECIFICATION.md` requirements and add a dated decision and reason at the top of `METHODOLOGY.md`. Preserve earlier entries and frozen run inputs.
- State which commands and comparisons passed. A run in the existing software environment does not establish that a clean environment can be restored.
