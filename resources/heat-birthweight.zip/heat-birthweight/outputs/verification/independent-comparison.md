# Independent implementation comparison

Both implementations started from the same specification and synthetic input file. R term names are normalized to their Python equivalents only for comparison. No numerical values are transformed.

| Check | Agreement | Maximum absolute difference |
|---|---|---|
| data/raw/births.csv | Yes | Exact identity |
| specification.md | Yes | Exact identity |
| sample membership | Yes | Exact identity |
| design-matrix.csv | Yes | 0 |
| coefficients.csv | Yes | 1.82e-12 |
| covariance.csv | Yes | 5.8e-11 |
| fitted-values.csv | Yes | 9.28e-11 |
| contrasts.csv | Yes | 3.02e-12 |
